package model;
/**
 * Model: Room Specification
 * New Rooms will get specified by this class
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/

import java.util.ArrayList;

public class Room {
    private String roomNum;
    private int roomCapacity;


    public Room(String roomNum, int roomCapacity){
        this.roomNum=roomNum;
        this.roomCapacity=roomCapacity;

    }

    public String getRoomNum() {
        return roomNum;
    }

    public int getRoomCapacity() {
        return roomCapacity;
    }
}
