package model;
/**
 * Model: Schedule Class connection to SQL Database
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
public class ScheduleDB {
}
