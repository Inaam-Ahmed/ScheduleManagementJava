package model;
/**
 * Model: Leaf Student Specification
 * New leaf students will get specified by this class
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
import java.util.ArrayList;

public class LeafStudent {
    private String studentName;
    private String studentNumber;
    private String studentSection;


    public LeafStudent(String studentName, String studentNumber, String studentSection) {
        this.studentName = studentName;
        this.studentNumber = studentNumber;
        this.studentSection = studentSection;

    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String getStudentSection() {
        return studentSection;
    }

    public void setStudentSection(String studentSection) {
        this.studentSection = studentSection;
    }
}
