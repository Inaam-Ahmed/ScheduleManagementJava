package model;
/**
 * Model: Section Specification
 * New Section will get specified by this class
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
import java.util.ArrayList;

public class Section {
    private String sectionName;
    private static int sectionCount=0;
    private ArrayList<LeafStudent> listOfStudents;


    public Section(String sectionName) {
        this.sectionName= sectionName;
        sectionCount++;

    }
    public boolean addToSection(LeafStudent LS){
        if(this.sectionName.equals(LS.getStudentSection()))
        {
            listOfStudents.add(LS);
            System.out.println("Student Added to section");
            return true;
        }

        return false;
    }

    public int getSectionStrength(){
        return this.listOfStudents.size();
    }
    public ArrayList<LeafStudent> getAllStudents() {
        return this.listOfStudents;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }
}
