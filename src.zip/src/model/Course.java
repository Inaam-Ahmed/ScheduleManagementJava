package model;
/**
 * Model: Course Specification
 * New courses  will get specified by this class
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
import java.util.ArrayList;

public class Course {
    private String courseCode;
    private String courseName;
    private int creditHours;
    private boolean isLabCourse;

    public Course(String courseCode, String courseName,int creditHours, boolean isLabCourse) {
        this.courseCode = courseCode.toLowerCase();
        this.courseName = courseName.toLowerCase();
        this.creditHours= creditHours;
        this.isLabCourse = isLabCourse;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public boolean isLabCourse() {
        return isLabCourse;
    }
}
