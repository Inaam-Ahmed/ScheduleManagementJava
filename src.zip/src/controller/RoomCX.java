package controller;
/**
 * Controller of Room Scene
 * This controller is responsible for input of room information
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.AdminDB;
import model.Room;
import model.RoomDB;

public class RoomCX {

    Room theRoom;
    @FXML
    private TextField roomNum;
    @FXML
    private TextField roomCapacity;
    @FXML
    private Button submitButton;
    @FXML
    private Button cancelButton;

    @FXML
    public void enter_room(ActionEvent e)
    {
        String  cap=null;
        if(e.getSource().equals(submitButton)){
            cap= roomCapacity.getText();
         System.out.println(cap);
            theRoom= new Room(roomNum.getText(), Integer.parseInt(cap));
            try {
                RoomDB.addOb(theRoom);
                Stage stage=(Stage) submitButton.getScene().getWindow();
                stage.close();
            }catch (Exception ex){
                return;
            }



        }
        else if (e.getSource().equals(cancelButton)){
            Stage stage=(Stage) cancelButton.getScene().getWindow();
            stage.close();
        }
        else{

        }
    }

}
