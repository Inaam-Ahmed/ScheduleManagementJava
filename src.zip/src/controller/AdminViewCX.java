package controller;
/**
 * Controller of Admin View Scene
 * This controller is responsible for handeling request of legitimate admin
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import javafx.event.ActionEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.*;

import java.util.ArrayList;
import java.util.List;

public class AdminViewCX {
    @FXML
    private Button logoutButton;
    @FXML
    private Button putCourse;
    @FXML
    private Button putInstructor;
    @FXML
    private Button putLeafStudent;
    @FXML
    private Button putRoom;
    @FXML
    private Button putSection;
    @FXML
    private Button putTimeSlot;
    @FXML
    private Button generateSchedule;
    @FXML
    private BorderPane mainBorderPane;


    @FXML
    public void admin_view(ActionEvent e) {
        if (e.getSource().equals(logoutButton)) {
            System.out.println("Logout of System");
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.close();

            try {
                FXMLLoader fxmlLoader2 = new FXMLLoader(getClass().getResource("/view/login.fxml"));
                Parent root2 = fxmlLoader2.load();
                Stage stage2 = new Stage();
                stage2.setScene(new Scene(root2, 800, 600));
                stage2.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }


        } else if (e.getSource().equals(putCourse)) {

            try {
                FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/view/enter_course.fxml"));
                Parent root1 = fxmlLoader1.load();
                Stage stage1 = new Stage();
                stage1.setScene(new Scene(root1, 800, 600));
                stage1.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource().equals(putInstructor)) {
            try {
                FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/view/enter_instructor.fxml"));
                Parent root1 = fxmlLoader1.load();
                Stage stage1 = new Stage();
                stage1.setScene(new Scene(root1, 800, 600));
                stage1.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else if (e.getSource().equals(putLeafStudent)) {

            try {
                FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/view/enter_leafstudent.fxml"));
                Parent root1 = fxmlLoader1.load();
                Stage stage1 = new Stage();
                stage1.setScene(new Scene(root1, 800, 600));
                stage1.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else if (e.getSource().equals(putRoom)) {
            try {
                FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/view/enter_room.fxml"));
                Parent root1 = fxmlLoader1.load();
                Stage stage1 = new Stage();
                stage1.setScene(new Scene(root1, 800, 600));
                stage1.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource().equals(putSection)) {
            try {
                FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/view/enter_section.fxml"));
                Parent root1 = fxmlLoader1.load();
                Stage stage1 = new Stage();
                stage1.setScene(new Scene(root1, 800, 600));
                stage1.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else if (e.getSource().equals(putTimeSlot)) {
            try {
                FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/view/enter_time_slot.fxml"));
                Parent root1 = fxmlLoader1.load();
                Stage stage1 = new Stage();
                stage1.setScene(new Scene(root1, 800, 600));
                stage1.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else if (e.getSource().equals(generateSchedule)) {
            try {
                FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/view/schedule.fxml"));
                Parent root1 = fxmlLoader1.load();
                Stage stage1 = new Stage();
                stage1.setScene(new Scene(root1, 1000, 600));
                stage1.show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}