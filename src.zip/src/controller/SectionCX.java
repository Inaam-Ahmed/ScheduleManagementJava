package controller;
/**
 * Controller of Section Scene
 * This controller is responsible for input of Section information
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.*;

public class SectionCX {
    @FXML
    private TextField sectionName;
    @FXML
    private Button submitButton;
    @FXML
    private Button cancelButton;
    @FXML

    Section theSection;
    public void enter_section(ActionEvent e){
        if(e.getSource().equals(submitButton)){
            theSection = new Section(sectionName.getText());
            System.out.println(theSection.getSectionName());

            try {
                SectionDB.addOb(theSection);
                // SectionDB.getOb();
                //SectionDB.delOb("masc");
                Stage stage=(Stage) submitButton.getScene().getWindow();
                stage.close();
            }catch (Exception ex){
                return;
            }


        }
        else if (e.getSource().equals(cancelButton)){
            Stage stage=(Stage) cancelButton.getScene().getWindow();
            stage.close();

        }
        else{

        }


    }




}
