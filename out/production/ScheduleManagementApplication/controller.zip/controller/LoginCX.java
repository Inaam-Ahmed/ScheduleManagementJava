package controller;
/**
 * Controller of Login Dialogue
 * This controller is responsible for input and verification of valid admin
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.AdminDB;
import org.omg.Messaging.SYNC_WITH_TRANSPORT;

public class LoginCX {

    @FXML
    private TextField userName;
    @FXML
    private TextField password;
    @FXML
    private Button loginButton;
    @FXML
    private Button cancelButton;

    @FXML
    public void login(ActionEvent e){
    if(e.getSource().equals(loginButton))
    {
        System.out.println("Check");
        boolean islogin=AdminDB.getOb(userName.getText(),password.getText());
        System.out.println(islogin);
        if(islogin)
        {
        System.out.println("Present System after login");
        try {
            FXMLLoader fxmlLoader3 = new FXMLLoader(getClass().getResource("/view/admin_view.fxml"));
            Parent root3 = fxmlLoader3.load();
            Stage stage3 = new Stage();
            stage3.setScene(new Scene(root3,800,600));
            stage3.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
            Stage stage=(Stage) loginButton.getScene().getWindow();
            stage.close();
        }

    }
        else if(e.getSource().equals(cancelButton))
        {
            System.out.println("Move back to Main Window");
            Stage stage=(Stage) cancelButton.getScene().getWindow();
            stage.close();
        }
    }

}
