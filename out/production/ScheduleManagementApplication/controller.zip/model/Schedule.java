package model;
/**
 * Model: Instantiations of all schedules will be specified by this clas
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 *
 **/
import jdk.nashorn.internal.ir.Assignment;
import model.InstructorAssignment;
import model.RoomAssignment;

import java.util.ArrayList;

public class Schedule {
    private ArrayList<SlotAssignment> listOfSlotAssignments;
    private ArrayList<RoomAssignment> listOfRoomAssignment;

    public Schedule(){

        listOfSlotAssignments=SlotAssignmentDB.getOb();
    }
}
