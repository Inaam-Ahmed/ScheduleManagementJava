package model;
/**
 * Model: Internal Class use to assigned instructors and assigned rooms to time slots
 *
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by me our both.
 **/

import java.util.ArrayList;
import java.util.Random;

public class SlotAssignment {

    private String courseCode;
    private String courseName;
    private int creditHours;
    private boolean isLabCourse;
    private String instructorID;
    private String instructorName;
    private String roomNum;
    private String Section;

    private int startTimeHr;
    private int startTimeMn;
    private int endTimeHr;
    private int endTimeMn;
    private int slotLength;
    private String dayOfSlot;
    private String roomNumber;
    private Random random;


    private ArrayList<InstructorAssignment> listOfInstructorAssignments;
    private ArrayList<TimeSlot> listOfTimeSlots;

    public ArrayList<SlotAssignment> listOfSlotAssignments;

    public SlotAssignment() {
        random = new Random();

//        SlotAssignmentDB.
    }


    public SlotAssignment(String courseCode, String instructorName, String roomNum, int startTimeHr, int startTimeMn, int endTimeHr, int endTimeMn, String dayOfSlot) {
        this.courseCode = courseCode;
        this.instructorName = instructorName;
        this.roomNum = roomNum;
        this.startTimeHr = startTimeHr;
        this.startTimeMn = startTimeMn;
        this.endTimeHr = endTimeHr;
        this.endTimeMn = endTimeMn;
        this.dayOfSlot = dayOfSlot;
    }

    public void doSlotAssignment() {

        listOfInstructorAssignments = InstructorAssignmentDB.getOb();
        listOfTimeSlots = TimeSlotDB.getOb();
        listOfSlotAssignments = new ArrayList<>();
        SlotAssignment theSlotAssignment = new SlotAssignment();
        for (int i = 0; i < listOfTimeSlots.size(); i++) {
            System.out.println(listOfTimeSlots.get(i).getDayOfSlot() + "  " + listOfTimeSlots.get(i).getRoomNumber() + "  " + listOfTimeSlots.get(i).getStartTimeHr() + " " + listOfTimeSlots.get(i).getStartTimeMn() + " " + listOfTimeSlots.get(i).getEndTimeHr() + " " + listOfTimeSlots.get(i).getEndTimeMn());
        }
        SlotAssignmentDB.delOb();

        for (int i = 0; i < listOfInstructorAssignments.size(); i++) {
            System.out.println(listOfInstructorAssignments.get(i).getCourseCode() + "  " + listOfInstructorAssignments.get(i).getCreditHours() + "  " + listOfInstructorAssignments.get(i).getInstructorName() + " " + listOfInstructorAssignments.get(i).getCourseName() + " " + listOfInstructorAssignments.get(i).getInstructorID());
            int n = 0;
            switch (listOfInstructorAssignments.get(i).getCreditHours()) {
                case 1:
                    n = random.nextInt(listOfTimeSlots.size());
                    courseCode = listOfInstructorAssignments.get(i).getCourseCode();
                    instructorName = listOfInstructorAssignments.get(i).getInstructorName();
                    startTimeHr = listOfTimeSlots.get(i).getStartTimeHr();
                    startTimeMn = listOfTimeSlots.get(i).getStartTimeMn();
                    endTimeHr = listOfTimeSlots.get(n).getEndTimeHr();
                    endTimeMn = listOfTimeSlots.get(n).getEndTimeMn();
                    dayOfSlot = listOfTimeSlots.get(n).getDayOfSlot();
                    roomNum = listOfTimeSlots.get(n).getRoomNumber();

                    theSlotAssignment = new SlotAssignment(courseCode, instructorName, roomNum, startTimeHr, startTimeMn, endTimeHr, endTimeMn, dayOfSlot);
                    listOfSlotAssignments.add(theSlotAssignment);

                    SlotAssignmentDB.addOb(theSlotAssignment);
                    listOfTimeSlots.remove(n);
                    break;
                case 2:
                    for (int assign = 0; assign < 2; assign++) {
                        n = random.nextInt(listOfTimeSlots.size());
                        courseCode = listOfInstructorAssignments.get(i).getCourseCode();
                        instructorName = listOfInstructorAssignments.get(i).getInstructorName();
                        startTimeHr = listOfTimeSlots.get(n).getStartTimeHr();
                        startTimeMn = listOfTimeSlots.get(n).getStartTimeMn();
                        endTimeHr = listOfTimeSlots.get(n).getEndTimeHr();
                        endTimeMn = listOfTimeSlots.get(n).getEndTimeMn();
                        dayOfSlot = listOfTimeSlots.get(n).getDayOfSlot();
                        roomNum = listOfTimeSlots.get(n).getRoomNumber();
                        theSlotAssignment = new SlotAssignment(courseCode, instructorName, roomNum, startTimeHr, startTimeMn, endTimeHr, endTimeMn, dayOfSlot);
                        listOfSlotAssignments.add(theSlotAssignment);
                        SlotAssignmentDB.addOb(theSlotAssignment);
                        listOfTimeSlots.remove(n);
                    }
                    break;
                case 3:
                    for (int assign = 0; assign < 3; assign++) {
                        n = random.nextInt(listOfTimeSlots.size());
                        courseCode = listOfInstructorAssignments.get(i).getCourseCode();
                        instructorName = listOfInstructorAssignments.get(i).getInstructorName();
                        startTimeHr = listOfTimeSlots.get(n).getStartTimeHr();
                        startTimeMn = listOfTimeSlots.get(n).getStartTimeMn();
                        endTimeHr = listOfTimeSlots.get(n).getEndTimeHr();
                        endTimeMn = listOfTimeSlots.get(n).getEndTimeMn();
                        dayOfSlot = listOfTimeSlots.get(n).getDayOfSlot();
                        roomNum = listOfTimeSlots.get(n).getRoomNumber();
                        theSlotAssignment = new SlotAssignment(courseCode, instructorName, roomNum, startTimeHr, startTimeMn, endTimeHr, endTimeMn, dayOfSlot);
                        listOfSlotAssignments.add(theSlotAssignment);
                        SlotAssignmentDB.addOb(theSlotAssignment);
                        listOfTimeSlots.remove(n);
                    }
                    break;
                default:
                    System.out.println("No Slot Assignment Done");
            }


//            int k=0;
//                while(k<listOfInstructorAssignments.get(i).getCreditHours()){
//                    for(int j=0;j<listOfTimeSlots.size();j++){
//                        SlotAssignment theSlotAssignment=new SlotAssignment();
//                        int n=random.nextInt(listOfTimeSlots.size())+1;
//                        courseCode=listOfInstructorAssignments.get(i).getCourseCode();
//                        instructorName=listOfInstructorAssignments.get(i).getInstructorName();
//                        startTimeHr=listOfTimeSlots.get(i).getStartTimeHr();
//                        startTimeMn=listOfTimeSlots.get(i).getStartTimeMn();
//                        endTimeHr=listOfTimeSlots.get(n).getEndTimeHr();
//                        endTimeMn=listOfTimeSlots.get(n).getEndTimeMn();
//                        dayOfSlot=listOfTimeSlots.get(n).getDayOfSlot();
//                        roomNum=listOfTimeSlots.get(n).getRoomNumber();
//                        theSlotAssignment=new SlotAssignment(courseCode,instructorName,roomNum,startTimeHr,startTimeMn,endTimeHr,endTimeMn,dayOfSlot);
//                        SlotAssignmentDB.addOb(theSlotAssignment);
//                        listOfSlotAssignments.add(theSlotAssignment);
//                        listOfTimeSlots.remove(n);
//                       listOfInstructorAssignments.remove(i);
//
//                    }
//                    k++;
//                }
//            }


        }

    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public boolean isLabCourse() {
        return isLabCourse;
    }

    public String getInstructorID() {
        return instructorID;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public String getRoomNum() {
        return roomNum;
    }

    public String getSection() {
        return Section;
    }

    public int getStartTimeHr() {
        return startTimeHr;
    }

    public int getStartTimeMn() {
        return startTimeMn;
    }

    public int getEndTimeHr() {
        return endTimeHr;
    }

    public int getEndTimeMn() {
        return endTimeMn;
    }

    public int getSlotLength() {
        return slotLength;
    }

    public String getDayOfSlot() {
        return dayOfSlot;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public Random getRandom() {
        return random;
    }

    public ArrayList<InstructorAssignment> getListOfInstructorAssignments() {
        return listOfInstructorAssignments;
    }

    public ArrayList<TimeSlot> getListOfTimeSlots() {
        return listOfTimeSlots;
    }

}
