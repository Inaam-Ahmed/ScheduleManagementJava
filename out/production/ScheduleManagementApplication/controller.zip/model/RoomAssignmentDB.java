package model;

import jdk.nashorn.internal.ir.Assignment;

import java.sql.*;
import java.util.ArrayList;

/**
 * Model: Room Assignment connection to SQL Database
 * @author Inaam, Nixon
 * MUN_# 201692544
 * inaama@mun.ca, neo505@mun.ca
 * This file was prepared by Inaam Ahmed and Obi Nixon completed by both.
 *
 **/
public class RoomAssignmentDB {

        public static void addOb(RoomAssignment obj){
            try {
                // create a mysql database connection
                String myDriver = "com.mysql.jdbc.Driver";
                String myUrl = "jdbc:mysql://localhost:3306/schedule_pr";
                Class.forName(myDriver);
                Connection conn = DriverManager.getConnection(myUrl, "root", "adminadmin");

                // the mysql insert statement
                String query = " INSERT INTO roomassignment(sectionName,roomNum)"
                        + " VALUES (?, ?)";

                //create the mysql insert prepared statement
                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setString(1, obj.getSection());
                preparedStmt.setString(2, obj.getRoomNum());

                // execute the prepared statement
                preparedStmt.execute();

                conn.close();
            } catch (Exception e) {
                System.err.println("Got an exception!");
                System.err.println(e.getMessage());


            }
        }
        public static ArrayList<RoomAssignment> getOb(){
            ArrayList<RoomAssignment> listOfRoomAssignment=new ArrayList<RoomAssignment>();
            RoomAssignment theRoomAssignment;
            try {
                // create a mysql database connection
                String myDriver = "com.mysql.jdbc.Driver";
                String myUrl = "jdbc:mysql://localhost:3306/schedule_pr";
                Class.forName(myDriver);
                Connection conn = DriverManager.getConnection(myUrl, "root", "adminadmin");


                // the mysql get statement
                String query = "SELECT * FROM roomassignment";

                //Create Java Statement
                Statement st = conn.createStatement();

                // execute the query, and get a java result set
                ResultSet rs = st.executeQuery(query);

                while(rs.next()) {
                    String getSectionName = rs.getString("sectionName");
                    String getRoomNumber = rs.getString("roomNum");
                    System.out.println();
                    theRoomAssignment=new RoomAssignment(getSectionName,getRoomNumber);
                    listOfRoomAssignment.add(theRoomAssignment);
                }
                conn.close();
            } catch (Exception e) {
                System.err.println("Got an exception!");
                System.err.println(e.getMessage());

            }
            return listOfRoomAssignment;

        }
        public static void delOb(){
            try {
                // create a mysql database connection
                String myDriver = "com.mysql.jdbc.Driver";
                String myUrl = "jdbc:mysql://localhost:3306/schedule_pr";
                Class.forName(myDriver);
                Connection conn = DriverManager.getConnection(myUrl, "root", "adminadmin");
                Statement st = conn.createStatement();
                st.executeUpdate("truncate roomassignment");
                conn.close();
            } catch (Exception e) {
                System.err.println("Got an exception!");
                System.err.println(e.getMessage());
            }

        }



}
