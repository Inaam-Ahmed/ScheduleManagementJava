package model;

public class SectionStrength {
    private String sectionName;
    private int sectionStrength;

    public SectionStrength() {
    }

    public SectionStrength(String sectionName, int sectionStrength) {
        this.sectionName = sectionName;
        this.sectionStrength = sectionStrength;
    }

    public String getSectionName() {
        return sectionName;
    }

    public int getSectionStrength() {
        return sectionStrength;
    }
}